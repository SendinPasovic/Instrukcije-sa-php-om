#include<graphics.h>
#include <conio.h>
#include <iostream>
#include<windows.h>
#include "crtati.h"
#include "anim.h"


using namespace std;



int main (){
	/*
DWORD screenWidth = GetSystemMetrics (SM_CXSCREEN);
DWORD screenHeight = GetSystemMetrics (SM_CYSCREEN);
cout<<screenWidth<<endl;
cout<<screenHeight<<endl;*/
initwindow (1280, 1024);

crtanje();
while(1){
	
animacija();


}
getch();
  closegraph();


  

}

 

