#ifndef ANIMACIJA_H
#define ANIMACIJA_H

class animacija
{
	public:
		animacija(int i);
		
		~animacija();
	protected:
};

#endif
