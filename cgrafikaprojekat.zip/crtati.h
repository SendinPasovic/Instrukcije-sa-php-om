#ifndef CRTANJE_H
#define CRTANJE_H


void crtanje(){
	setcolor(GREEN);
line(0,337,521,539);
line(521,539,365,1040);
line(0,337,0,1024);
line(0,1024,365,1040);
setfillstyle(SOLID_FILL, GREEN);
floodfill(	347,672,GREEN);
setfillstyle(5,	0x00808000	);
bar (0,0,1280,120);
setcolor(BROWN);	
setfillstyle (SOLID_FILL, BROWN);
rectangle(155,950,218,683);
floodfill(156,949,6);
setcolor(0x00FFFFFF);
settextstyle(1,0,2);
outtextxy(0,900,"Labudovi na Vrelu Bosne");
outtextxy(0,970,"Adna Omeragi�");
setcolor(BROWN);
setlinestyle(0,USERBIT_LINE,3);
line(218,683,320,570);
line(195,686,256,537);
line(179,686,205,533);
line(170,686,144,534);
line(155,686,89,547);
setfillstyle(HATCH_FILL, 0x00008000);
circle(184,582,144);
floodfill(185,581,BROWN);
setcolor(0x00808000);
line (0,120,0,337);
line(0,337,521,539);
line(521,539,365,1040);
line(1358,801,1022,120);
setfillstyle(SOLID_FILL, 0x00808000);
floodfill(463,236,0x00808000);
line(365,1040,1280,1024);
line(1280,1024,1358,801);
line(1358,801,1022,120);
line(1022,120,0,120);
setcolor(0x00808000);
setfillstyle(SOLID_FILL, 0x00FFFF00);
setcolor(0x00808080	);
line(502,600,616,498);
line(616,498,1160,498);
line(1160,498,1270,562);
line(1270,562,1211,424);
line(1211,424,1071,398);
line(1071,398,523,398);
line(523,398,418,498);
line(418,498,502,600);
line(523,398,616,498);
line(1071,398,1160,498);
setfillstyle(SOLID_FILL, 0x00808080);
floodfill(853,429,0x00808080);
floodfill(562,485,0x00808080);
floodfill(1179,439,0x00808080);
setcolor(YELLOW);
circle(1232,50,71);
setfillstyle(SOLID_FILL,YELLOW);
floodfill(1232,50,YELLOW);
setcolor(0x00008000);
line(1022,120,1280,120);
line(1022,120,1358,801);
line(1350,801,1280,120);
setfillstyle(SOLID_FILL, GREEN);
floodfill(1182,173,GREEN);
setcolor(YELLOW);
line(1276,123,1287,169);
line(1234,130,1241,169);
line(1206,131,1199,171);
line(1173,113,1136,141);
line(1155,81,1110,100);
line(1146,50,1092,55);
line(1148,17,1087,15);

}

#endif
